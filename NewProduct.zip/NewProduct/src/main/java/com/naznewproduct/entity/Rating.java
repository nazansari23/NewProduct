package com.naznewproduct.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Table;

@Table
public class Rating {
    @Column
    private String userId;
    @Column
    private int rating;
    @Column
    private String comment;
    
    // Getters and setters
    
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	@Override
	public String toString() {
		return "Rating [userId=" + userId + ", rating=" + rating + ", comment=" + comment + "]";
	}
	public Rating() {
		
	}
	public Rating(String userId, int rating, String comment) {
		super();
		this.userId = userId;
		this.rating = rating;
		this.comment = comment;
	}

}
