package com.naznewproduct.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Table;

@Table
public class Availability {
    @Column
    private boolean inStock;
    @Column
    private int quantity;
    
    // Getters and setters
	public boolean isInStock() {
		return inStock;
	}
	public void setInStock(boolean inStock) {
		this.inStock = inStock;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Availability [inStock=" + inStock + ", quantity=" + quantity + "]";
	}
	
	public Availability() {
		
	}
	public Availability(boolean inStock, int quantity) {
		super();
		this.inStock = inStock;
		this.quantity = quantity;
	}


}
