package com.naznewproduct.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.naznewproduct.entity.Product;

public interface ProductRepository extends JpaRepository<Product, String> {

	Optional<Product> findById(int id);

}
